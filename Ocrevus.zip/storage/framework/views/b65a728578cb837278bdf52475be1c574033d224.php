

<?php $__env->startSection('contentInicial'); ?>

    <div class="main-em-container">
        <h2>Corriendo contra la EM para frenar la progresión</h2>

        <div class="gifs-container">
            <img src="img/gifs/Gif-1.gif" alt="img section gifs">
            <img src="img/gifs/Gif-2.gif" alt="img section gifs">
            <img src="img/gifs/Gif-3.gif" alt="img section gifs">
            <img src="img/gifs/Gif-4.gif" alt="img section gifs">
            <img src="img/gifs/Gif-5.gif" alt="img section gifs">
            <img src="img/gifs/muñequitos.png" alt="img section gifs">
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ocrevus\resources\views/Em.blade.php ENDPATH**/ ?>