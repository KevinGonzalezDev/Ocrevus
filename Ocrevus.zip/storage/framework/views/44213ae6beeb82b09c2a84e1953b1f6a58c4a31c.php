<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
 <head>
  <meta http-equiv="Content-type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="description" content="<?php echo e(strtotime(date('Y-m-d H:i:s'))); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link href="<?php echo e(asset('/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
  <title><?php echo e(config('app.name', 'Roche')); ?></title>
 </head>
 <body id="page-top">
  <main class="col-12 main">
   <article class="main__container">
    <header class="header shadow" id="header_fixed">
     <a class="col-3 col-md-2 btn-header mx-2 mx-md-0" href="<?php echo e(route('/')); ?>">
      <img class="img-fluid" src="<?php echo e(asset('/img/elements/ocrevus.png')); ?>">
     </a>
     <a class="col-2 col-md-1 btn-header mx-2 mx-md-0" href="<?php echo e(route('/')); ?>">
      <img class="img-fluid" src="<?php echo e(asset('/img/elements/logo.png')); ?>">
     </a>
     <button class="col-1 btn-header btnMenuNoCollapse ml-auto">
      <img class="img-fluid w-100" src="<?php echo e(asset('/img/elements/toggle.png')); ?>">
     </button>
     <div class="col-5 header__menu offset-3">
      <?php if(auth()->guard()->guest()): ?>
       <a class="col-4 btn-header <?php if(Request::is('/')): ?> active <?php endif; ?>" href="<?php echo e(route('/')); ?>">
        <p class="font-weight-bold m-0 small">Login</p>
       </a>
      <?php endif; ?>
      <a class="col-4 btn-header <?php if(Request::is('ranking')): ?> active <?php endif; ?>" href="<?php echo e(route('ranking')); ?>">
       <p class="font-weight-bold m-0 small">Ranking</p>
      </a>
      <?php if(auth()->guard()->check()): ?>
       <a class="col-4 btn-header <?php if(Request::is('game')): ?> active <?php endif; ?>" href="<?php echo e(route('game')); ?>">
        <p class="font-weight-bold m-0 small">Juego</p>
       </a>
       <a class="col-4 btn-header" href="<?php echo e(route('logout')); ?>">
        <img class="img-fluid w-60" src="<?php echo e(asset('/img/elements/cerrar.png')); ?>">
       </a>
      <?php endif; ?>
     </div>
    </header>
    <aside class="immovable">
     <a class="col-3 col-md-2 btn-header mx-2 mx-md-0" href="<?php echo e(route('/')); ?>">
      <img class="img-fluid" src="<?php echo e(asset('/img/elements/ocrevus.png')); ?>">
     </a>
     <a class="col-2 col-md-1 btn-header mx-2 mx-md-0" href="<?php echo e(route('/')); ?>">
      <img class="img-fluid" src="<?php echo e(asset('/img/elements/logo.png')); ?>">
     </a>
     <button class="col-1 btn-header btnMenuNoCollapse ml-auto">
      <img class="img-fluid w-100" src="<?php echo e(asset('/img/elements/toggle.png')); ?>">
     </button>
     <div class="col-5 header__menu offset-3">
      <?php if(auth()->guard()->guest()): ?>
       <a class="col-4 btn-header <?php if(Request::is('/')): ?> active <?php endif; ?>" href="<?php echo e(route('/')); ?>">
        <p class="font-weight-bold m-0 small">Login</p>
       </a>
      <?php endif; ?>
      <a class="col-4 btn-header <?php if(Request::is('ranking')): ?> active <?php endif; ?>" href="<?php echo e(route('ranking')); ?>">
       <p class="font-weight-bold m-0 small">Ranking</p>
      </a>
      <?php if(auth()->guard()->check()): ?>
       <a class="col-4 btn-header <?php if(Request::is('game')): ?> active <?php endif; ?>" href="<?php echo e(route('game')); ?>">
        <p class="font-weight-bold m-0 small">Juego</p>
       </a>
       <a class="col-4 btn-header" href="<?php echo e(route('logout')); ?>">
        <img class="img-fluid w-60" src="<?php echo e(asset('/img/elements/cerrar.png')); ?>">
       </a>
      <?php endif; ?>
     </div>
    </aside>
    <div class="middle">
     <?php echo $__env->yieldContent('content'); ?>
    </div>
   </article>
   <nav class="sidebar">
    <section class="sidebar__body mt-8">
     <?php if(auth()->guard()->guest()): ?>
      <a class="col-12 btn-body <?php if(Request::is('/')): ?> active <?php endif; ?>" href="<?php echo e(route('/')); ?>">
       <p class="font-weight-bold m-0">Login</p>
      </a>
     <?php endif; ?>
     <a class="col-12 btn-body <?php if(Request::is('ranking')): ?> active <?php endif; ?>" href="<?php echo e(route('ranking')); ?>">
      <h4 class="font-weight-bold m-0">Ranking</h4>
     </a>
     <?php if(auth()->guard()->check()): ?>
      <a class="col-12 btn-body <?php if(Request::is('game')): ?> active <?php endif; ?>" href="<?php echo e(route('game')); ?>">
       <h4 class="font-weight-bold m-0">Juego</h4>
      </a>
      <a class="col-12 btn-body" href="<?php echo e(route('logout')); ?>">
       <h4 class="font-weight-bold m-0">Cerrar Sesión</h4>
      </a>
     <?php endif; ?>
    </section>
   </nav>
   <a class="scroll-top" href="#page-top"><i class="fa fa-angle-up"></i></a>
  </main>
  
  <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
 </body>
</html>

<?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ocrevus\resources\views/layout/inicio.blade.php ENDPATH**/ ?>