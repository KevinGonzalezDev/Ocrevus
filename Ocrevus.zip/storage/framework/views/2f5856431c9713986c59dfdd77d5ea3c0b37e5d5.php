<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
 <head>
  <meta http-equiv="Content-type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="description" content="<?php echo e(strtotime(date('Y-m-d H:i:s'))); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link href="<?php echo e(asset('/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
  <title><?php echo e(config('app.name', 'Roche')); ?></title>
 </head>
 <body id="page-top">
  <main class="col-12 main">
   <article class="main__container">
    
    
    <div class="middle <?php if(Request::is('game')): ?> max-middle <?php endif; ?>">
     <?php echo $__env->yieldContent('content'); ?>
    </div>
   </article>
   <nav class="sidebar">
    <section class="sidebar__body mt-8">
     <a class="col-12 btn-body <?php if(Request::is('ranking')): ?> active <?php endif; ?>" href="<?php echo e(route('ranking')); ?>">
      <h4 class="font-weight-bold m-0">Ranking</h4>
     </a>
     <a class="col-12 btn-body <?php if(Request::is('game')): ?> active <?php endif; ?>" href="<?php echo e(route('game')); ?>">
      <h4 class="font-weight-bold m-0">Juego</h4>
     </a>
     <?php if(auth()->guard()->check()): ?>
      <a class="col-12 btn-body" href="<?php echo e(route('logout')); ?>">
       <h4 class="font-weight-bold m-0">Cerrar Sesión</h4>
      </a>
     <?php endif; ?>
    </section>
   </nav>
   <a class="scroll-top" href="#page-top"><i class="fa fa-angle-up"></i></a>
  </main>
  
  <link href="<?php echo e(asset('juego/css/style.css')); ?>" rel="stylesheet">
  <script src="<?php echo e(asset('juego/src/phaser.min.js')); ?>"></script>
  <script src="<?php echo e(asset('juego/src/common.js')); ?>"></script>
  <script src="<?php echo e(asset('juego/src/boot.js')); ?>"></script>
  <script src="<?php echo e(asset('juego/src/preloader.js')); ?>"></script>
  <script src="<?php echo e(asset('juego/src/game.js')); ?>"></script>
  <script src="<?php echo e(asset('juego/src/init.js')); ?>"></script>
  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
 </body>
</html>

<?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ocrevus\resources\views/layout/game.blade.php ENDPATH**/ ?>