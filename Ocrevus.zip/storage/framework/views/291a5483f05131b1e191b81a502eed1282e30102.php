<?php $__env->startSection('content'); ?>
 <article class="col-11 col-sm-8 col-md-5 col-xl-4 section-login">
  <picture class="mt-5 mt-sm-4 mt-md-0">
   <img class="img-fluid" src="<?php echo e(asset('/img/elements/road.png')); ?>">
  </picture>
  <p class="mt-4 small text-blue text-center">Ingresa con tu correo electrónico <br>y contraseña para acceder al panel</p>
  <form class="container-form" method="post" action="<?php echo e(route('login.back')); ?>">
   <?php echo csrf_field(); ?>
   <div class="col-10 my-1">
    <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" title="Ingrese su Correo Electrónico" placeholder="CORREO ELECTRÓNICO*" maxlength="100" id="email" name="email" required value="<?php echo e(old('email')); ?>">
    <?php echo $errors->first('email', '<p class="form-error small_2">:message</p>'); ?>

   </div>
   <div class="col-10 my-1">
    <input class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" type="password" title="Ingrese su Contraseña" placeholder="CONTRASEÑA*" maxlength="100" id="password" name="password" required value="<?php echo e(old('password')); ?>">
    <?php echo $errors->first('password', '<p class="form-error small_2">:message</p>'); ?>

   </div>
   <div class="col-9 col-md-8 my-4 my-md-2">
    <button class="btn-blue" type="submit">
     <p class="m-0 small">INGRESAR</p>
    </button>
   </div>
  </form>
 </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ocrevus\resources\views/back/login.blade.php ENDPATH**/ ?>