<?php if(session('user.login')): ?>
 <script>
  Swal.fire({
    icon: "success",
    title: "<h5 class='text-center'>¡Buen Trabajo!</h5>",
    html: "<h6 class='text-center'><?php echo e(session('user.login')); ?></h6>"
  })
 </script>
<?php elseif(session('user.fail')): ?>
 <script>
  Swal.fire({
    icon: "error",
    title: "<h5 class='text-center'>Atención</h5>",
    html: "<h6 class='text-center'><?php echo e(session('user.fail')); ?></h6>"
  })
 </script>
<?php elseif(session('user.store')): ?>
 <script>
  Swal.fire({
    icon: "success",
    title: "<h5 class='text-center'>¡Buen Trabajo!</h5>",
    html: "<h6 class='text-center'><?php echo e(session('user.store')); ?></h6>"
  })
 </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Ocrevus\resources\views/includes/alert.blade.php ENDPATH**/ ?>