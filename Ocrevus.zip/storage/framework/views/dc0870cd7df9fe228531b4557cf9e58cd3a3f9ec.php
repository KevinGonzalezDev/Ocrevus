<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">

    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="description" content="<?php echo e(strtotime(date('Y-m-d H:i:s'))); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="<?php echo e(asset('/img/favicon.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
    <title><?php echo e(config('app.name', 'Roche')); ?></title>
</head>
<body class="general-body">





      


  <script src="<?php echo e(asset('/juego/src/common.js')); ?>"></script>
  <script src="<?php echo e(asset('/juego/src/boot.js')); ?>"></script>

  <script src="<?php echo e(asset('/juego/src/init.js')); ?>"></script>
  <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</body>
</html>
<?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ocrevus\resources\views/layout/empty.blade.php ENDPATH**/ ?>