<div class="main-container">



<div class="login-container">

    <img src="img/muñequito.png" alt="pj">

    <div class="login">
    <form action="<?php echo e(route('login.front')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h2>Identifíquese</h2>
                <p>¡El tiempo es cerebro!</p>

                <label>*Obligatorio</label>
                <input class="<?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" placeholder="Email*" required value="<?php echo e(old('email')); ?>">
                <?php echo $errors->first('email', '<p class="form-error small_2">:message</p>'); ?>

                
                <input type="text" name="name" id="name" placeholder="Username*">
                <input type="text" name="ciudad" id="ciudad" placeholder="Ciudad (opcional)">

                <input type="submit" value="Iniciar sesión" id="iniciar-sesion">

                <div class="condiciones-container">
                    <input type="checkbox" name="condiciones" id="condicicones" required>
                <p>Acepto los &nbsp<a href="<?php echo e(route('popup')); ?>" id="condiciones">términos y condiciones</a></p> 
                </div>

            </form>
        </div>
</div> 

</div>

    <div class="bottom-logos-container">
        <img src="img/ocrevus-logo.png" alt="logo ocrevus" id="logo-ocrevus">
        <img src="img/logo-roche.png" alt="logo roche" id="logo-roche">
    </div>

    <script src="js/popup.js"></script>

<script>
    function redirect(){
        location.href = "game";
    }
</script>
<?php echo $__env->make('layout.empty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ocrevus\resources\views/welcome.blade.php ENDPATH**/ ?>